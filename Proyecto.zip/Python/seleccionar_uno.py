#importación del módulo
from atexit import register
from dataclasses import dataclass
import psycopg2

#conexión a la base de datos
conn = psycopg2.connect(user='postgres',
                       password='3126',
                       host='localhost',
                       port='5432',
                       database='Google drive')

#crear cursor
cur = conn.cursor()

sql = 'SELECT * FROM usuario WHERE codigo_usuario=%s'

codigo_usuario = input('ingrese el id del registro a mostrar: ')

cur.execute(sql, codigo_usuario)

registro = cur.fetchone()

print(registro)

cur.close()
conn.close()