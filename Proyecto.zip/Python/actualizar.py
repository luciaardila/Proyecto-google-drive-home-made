#importación del módulo
from atexit import register
from dataclasses import dataclass
import psycopg2

#conexión a la base de datos
conn = psycopg2.connect(user='postgres',
                       password='3126',
                       host='localhost',
                       port='5432',
                       database='Google drive')

#crear cursor
cur = conn.cursor()

#crear sentencia
sql = 'UPDATE usuario SET codigo_usuario=%s, nombre_usuario=%s, correo=%s, clave_usuario=%s, archivo_guardados=%s, no_roll=%s, no_perimiso1=%s, codigo_carpeta1=%s, codigo_archivo1=%s'

codigo = input('Ingrese el codigo')
nombre = input('Ingrese el nombre')
correo = input('Ingrese el correo')
clave = input('Ingrese la clave')
archivo_guardados = input('Ingrese los archivos guardados')
no_roll = input('Ingrese número de rol')
no_perimiso1 = input('Ingrese el número de permisos')
codigo_carpeta1 = input('Ingrese el codigo de carpeta')
codigo_archivo1 = input('Ingrese el codigo de archivo')

datos = (codigo,nombre,correo,clave,archivo_guardados,no_roll,no_perimiso1,codigo_carpeta1,codigo_archivo1)

#hacer uso del metodo execute
cur.execute(sql,datos)

#guardar registro
conn.commit()

#registros insertados
actualizacion = cur.rowcount()

#mensaje
print("registros actualizado: {actualizacion}")

#cerrar conexión
cur.close()
conn.close()