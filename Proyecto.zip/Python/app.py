import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import pandas as pd
from conection import Connection
import conSQL as sql

external_stylesheets = ["https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css"]

# Inicializacion app dash
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


# Casos por pais
con = Connection()
con.openConnection()
query = pd.read_sql_query(sql.IndUso(), con.connection)
con.closeConnection()
dfCases = pd.DataFrame(query, columns=["nombre", "archivo_guardados"])

# Grafico barras
figBarCases = px.bar(dfCases, x="nombre", y="archivo_guardados", title="Archivos guardados")

# Layout
app.layout = html.Div(children=[
    html.H1(children='Cantidad de archivos por usuario'),
    dcc.Graph(
        id='barArchporUsr',
        figure=figBarCases
    )
])

if __name__ == '__main__':
    app.run_server(debug=True)